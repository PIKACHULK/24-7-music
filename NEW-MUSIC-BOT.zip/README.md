## Latest Updates

> We are  waiting for Discord.js to update to v13 (as a stable version) so we can start updating the bot again. We can't fix all of them right now.

##  Tutorial

A Tutorial has been uploaded on YouTube  Watch it by clicking [here](https://www.youtube.com/channel/UC2Xcy7DXRL3RwgquBun6QGg)


## [Support Server](https://discord.gg/SY7DjDpwpk)

Do you have any issues with the bot? Head to our [Discord Server](https://discord.gg/SY7DjDpwpk) where we can help you faster than creating a GitHub issue




## HOW TO RUN

you can run this bot on repl,glitch and heroku, vps user can join support server



## FEATURES

247 VC <br> 1O+ FILTERS <br> LAG FREE MUSIC QUALITY

## SETUP
put token in .env and fill config.json
npm install
npm start

# LICENCE

YOU CANT RUN CODE WITHOUT JOINNING OUR SUPPORT SERVER ELSE WE WILL TAKE DOWN YOUR BOT
