const discord  =require("discord.js")
module.exports  = {
name: "about",
aliases: ["info","botinfo","stats"], 
botPermission: ["EMBED_LINKS","USE_EXTERNAL_EMOJIS"],
run : async (client,message,args )=> {
  
  
  
  let embed  = new discord.MessageEmbed()
    
   .setColor("GREEN")
 .setAuthor(`${client.user.username} Information`,client.user.displayAvatarURL())
 
    
.addField(`
**DEVELOPERS**`,
`@ⴽ𝐁𝐇・𝐑𝐄𝐗𝐗𝐘乛ᴛᴇʙ#9099 
@ⴽBH・NOVEL₊˚ᴮᴴ#9301 `)

.addField(`**PLATFORM**`,
`${process.platform}`)

.addField(`**SERVERS**`,
`${client.guilds.cache.size}`)

.addField(`**PING**`,
`${client.ws.ping}`)

.addField(`**GUILD ID**`,
`${message.guild.id}`)





message.channel.send(embed)
}}