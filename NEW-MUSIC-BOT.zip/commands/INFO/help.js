const discord  =  require("discord.js")
module.exports = {
  name: "help",
   botPermission: ["EMBED_LINKS", "READ_MESSAGE_HISTORY","USE_EXTERNAL_EMOJIS","ADD_REACTIONS"],
 
  run: async (client,message,args) => { 
    
    const embed = new discord.MessageEmbed()
    .setColor("#5FFF86")
 .setAuthor("Help Comammd",client.user.displayAvatarURL())
 .setURL(`https://github.com/parasop`)
.setDescription(`Hey! This is F-RADIO. Am here to provide you 24/7 high quality music.`)

.addField(`Everyone comammds [7]`,
`\`join,lyrics,play,queue,search,spotify,
soundcloud\``)

.addField(`Dj commands [13]`,
`\`back,clear,forward,jump,loop,pause,
resume,remove,rewind,shuffle,
skip,stop,volume\``)

.addField(`Admin commands [4]`,
`\`prefix,setdj,removedj,settings\``)

.addField(`Premium commands [10]`,
`\`24/7,autoplay,8d,basboost,clearfilter,equalizer,
nightcore,rate,speed,vaporwave\``)

.addField(`Utility commands [7]`,
`\`about,help,info,invite,ping,
uptime,vote\``)

.addField(`Dev commands [4]`,
`\`status,ban,addPremium,lavalink,changeLog\``)

.addField(`Links [3]`, 
`[Invite me](https://discord.com/api/oauth2/authorize?client_id=888087050488791080&permissions=2209401920&scope=bot) | [Support server](https://discord.gg/T4HZpbTxrF) | [Vote](https://discordbotlist.com/bots/f-radio/upvote)`)
 

message.channel.send(embed)
  }
}