const discord  =  require("discord.js")
module.exports = {
  name: "invite",
   botPermission: ["EMBED_LINKS", "READ_MESSAGE_HISTORY","USE_EXTERNAL_EMOJIS","ADD_REACTIONS"],
 
  run: async (client,message,args) => {
    
    
    const embed = new discord.MessageEmbed()
    .setColor("BLUE")
 .setAuthor("INVITE F-RADIO BOT",client.user.displayAvatarURL())
.setDescription(`

[F-RADIO 1](https://discord.com/api/oauth2/authorize?client_id=888087050488791080&permissions=37080400&scope=bot)

[F-RADIO 2](https://discord.com/api/oauth2/authorize?client_id=888100554906140692&permissions=139652951360&scope=bot)

[F-RADIO 3](https://discord.com/api/oauth2/authorize?client_id=888105720833245246&permissions=8&scope=bot)

[SUPPORT SERVER](https://discord.gg/T4HZpbTxrF)
`)
message.channel.send(embed)


}}