const discord  =  require("discord.js")
module.exports = {
  name: "redeem",
   botPermission: ["EMBED_LINKS", "READ_MESSAGE_HISTORY","USE_EXTERNAL_EMOJIS","ADD_REACTIONS"],
 
  run: async (client,message,args) => {
    
    
    const embed = new discord.MessageEmbed()
    .setColor("BLUE")
 .setAuthor("REDEEM",client.user.displayAvatarURL())
.setDescription(`

\`SOON THANKS FOR USE THIS COMMAND\`



[SUPPORT SERVER](https://discord.gg/jw7VPGE2tv)
`)
message.channel.send(embed)


}}