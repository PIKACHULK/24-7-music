
const discord = require('discord.js');
module.exports = {
	name: 'support',
	botPermission: [
		'EMBED_LINKS',
		'READ_MESSAGE_HISTORY',
		'USE_EXTERNAL_EMOJIS',
		'ADD_REACTIONS'
	],

	run: async (client, message, args) => {
		const embed = new discord.MessageEmbed()
			.setColor('RED')
			.setAuthor('SUPPORT', client.user.displayAvatarURL())
			.setDescription(`


<a:yellow_arrow:879006464306462780> [VOTE DBL](https://discordbotlist.com/bots/f-radio/upvote)



<a:ZS_heart:879006497579859989> [SUPPORT SERVER](https://discord.gg/T4HZpbTxrF)
`);
		message.channel.send(embed);
	}
};
