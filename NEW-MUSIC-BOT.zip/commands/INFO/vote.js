const discord  =  require("discord.js")
module.exports = {
  name: "vote",
   botPermission: ["EMBED_LINKS", "READ_MESSAGE_HISTORY","USE_EXTERNAL_EMOJIS","ADD_REACTIONS"],
 
  run: async (client,message,args) => {
    
    
    const embed = new discord.MessageEmbed()
    .setColor("BLUE")
 .setAuthor("VOTE",client.user.displayAvatarURL())
.setDescription(`

[VOTE DBL](https://discordbotlist.com/bots/f-radio/upvote)


**SUPPORT SERVER**
[SUPPORT SERVER](https://discord.gg/jw7VPGE2tv)
`)
message.channel.send(embed)


}}